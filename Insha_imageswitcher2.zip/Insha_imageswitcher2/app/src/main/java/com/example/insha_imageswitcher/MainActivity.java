package com.example.insha_imageswitcher;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
Button b1 ,b2;
ImageView iv;
boolean flag;
int images[]={R.drawable.space1,R.drawable.spac2,R.drawable.space3};
int i=0,j=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        iv=(ImageView) findViewById(R.id.img);
        b1=(Button) findViewById(R.id.b1);
        b2=(Button) findViewById(R.id.b2);
        flag=true;
        b1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                iv.setImageResource(images[i]);
                i++;
                if (i == 3) {
                    i = 0;
                }
            }
        });
        b2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                iv.setImageResource(images[i]);
                j--;
                if(j==0){
                    j=3;
                }

            }
        });

    }
}