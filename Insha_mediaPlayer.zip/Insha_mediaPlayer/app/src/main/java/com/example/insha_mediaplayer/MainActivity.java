package com.example.insha_mediaplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

     int starttime =0;
     int stoptime=0;
     int forwardtime = 5000;
     int rewindtime = 5000;
   MediaPlayer mediaPlayer, mediaplayernew;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
}