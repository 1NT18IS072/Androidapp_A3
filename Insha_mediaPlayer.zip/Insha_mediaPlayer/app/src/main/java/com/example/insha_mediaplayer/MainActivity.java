package com.example.insha_mediaplayer;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

     int starttime =0;
     int stoptime=0;
     int forwardtime = 5000;
     int rewindtime = 5000;
   MediaPlayer mediaPlayer, mediaplayernew;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
mediaPlayer = mediaPlayer.create(this,R.raw.bluebird);
        TextView songtitle = findViewById(R.id.text3);
        songtitle.setText("The Nights");
        Button play= findViewById(R.id.play);
        play.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Playing...", Toast.LENGTH_LONG).show();
            }
        });

        Button pause = findViewById(R.id.pause);
        pause.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "song paused", Toast.LENGTH_LONG).show();
            }
        });

        Button forward = findViewById(R.id.forward);
        pause.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                int currentpos = mediaPlayer.getCurrentPosition();
                if((currentpos+forwardtime)<=(stoptime=mediaPlayer.getDuration())){
                    mediaPlayer.seekTo(currentpos+forwardtime);
                }

            }
        });

        Button rewind = findViewById(R.id.rewind);
        pause.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                int currentpos = mediaPlayer.getCurrentPosition();
                if((currentpos-rewindtime)>=0){
                    mediaPlayer.seekTo(currentpos-rewindtime);
                }

            }
        });

        Button stop= findViewById(R.id.stop);
        play.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Song stopped playing", Toast.LENGTH_LONG).show();
                mediaPlayer.stop();
                mediaPlayer=mediaplayernew;
            }
        });
        Button restart= findViewById(R.id.restart);
        play.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Song Restarted", Toast.LENGTH_LONG).show();
                mediaPlayer.seekTo(0);
                mediaPlayer.start();
            }
        });

    }
}