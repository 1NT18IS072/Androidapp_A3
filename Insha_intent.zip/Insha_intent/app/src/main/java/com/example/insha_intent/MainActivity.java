package com.example.insha_intent;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static java.lang.Integer.*;

public class MainActivity extends AppCompatActivity {
    EditText num1, num2;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1 = findViewById(R.id.num1);
        num2 = findViewById(R.id.num2);
        btn = findViewById(R.id.btn);
        int n1 = parseInt(num1.getText().toString());
        int n2 = parseInt(num2.getText().toString());
        // add both number and store it to ans
        final int ans = n1 + n2;
        btn.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), result.class);
                intent.putExtra("ans", String.valueOf(ans));
                    startActivity(intent);

            }

        });
    }
}